import java.util.List;
import java.util.ArrayList;

public class Main {
  static <T> void copy(List<? extends T> source, List<? super T> target) {
    for (T item : source) target.add(item);
  }
  public static void main(String[] args) {
    List<Integer> source = List.of(1, 2);
    List<Number> target = new ArrayList<>();
    copy(source, target);
    assert target.equals(List.of(1, 2));
    Number first = target.get(0);
    assert first.intValue() == 1;
  }
}
