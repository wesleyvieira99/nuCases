import java.util.HashMap;
import java.util.Map;
import java.util.List;

public class Main {
  public static void main(String[] args) {
    Map<String, Integer> counts = new HashMap<>();
    for (String type : List.of("paid", "paid", "failed")) {
      counts.merge(type, 1, Integer::sum);
    }
    assert counts.get("paid") == 2;
    assert counts.get("failed") == 1;
    counts.merge("failed", 1, (oldValue, newValue) -> null);
    assert !counts.containsKey("failed");
  }
}
