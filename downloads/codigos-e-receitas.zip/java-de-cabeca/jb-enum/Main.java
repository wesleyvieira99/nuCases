public class Main {
    enum Estado { PENDENTE, APROVADO, RECUSADO }
    public static void main(String[] args) {
        Estado atual = Estado.valueOf("APROVADO");
        assert atual == Estado.APROVADO;
        assert atual.name().equals("APROVADO");
        assert Estado.values().length == 3;
        for (Estado estado : Estado.values()) {
            assert estado != null;
        }
    }
}
