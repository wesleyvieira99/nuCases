public class Main {
    static String classificar(String texto) {
        if (texto == null || texto.isBlank()) {
            return "vazio";
        }
        return texto.length() > 0 ? "preenchido" : "vazio";
    }
    public static void main(String[] args) {
        assert classificar(null).equals("vazio");
        assert classificar(" ").equals("vazio");
        assert classificar("java").equals("preenchido");
    }
}
