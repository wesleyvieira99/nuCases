import java.util.List;

public class Main {
  public static void main(String[] args) {
    List<Integer> values = List.of(2, 3, 4);
    int sum = values.stream().reduce(0, Integer::sum);
    int empty = List.<Integer>of().stream().reduce(0, Integer::sum);
    int primitiveSum = values.stream().mapToInt(Integer::intValue).sum();
    assert sum == 9;
    assert empty == 0;
    assert primitiveSum == sum;
  }
}
