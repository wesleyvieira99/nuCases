public class Main {
    public static void main(String[] args) {
        String original = "  a.b.  ";
        String limpo = original.strip();
        String[] partes = limpo.split("\\.", -1);
        assert partes.length == 3 && partes[2].isEmpty();
        assert limpo.replace(".", "-").equals("a-b-");
        assert original.startsWith("  ");
        assert "  ".isBlank();
    }
}
