import java.util.Arrays;
import java.util.Collections;
import java.util.ArrayList;
import java.util.List;

public class Main {
  public static void main(String[] args) {
    int[] numbers = {5, 1, 3};
    Arrays.sort(numbers);
    assert Arrays.equals(numbers, new int[] {1, 3, 5});
    assert Arrays.binarySearch(numbers, 3) == 1;
    List<Integer> values = new ArrayList<>(List.of(5, 1, 3));
    Collections.sort(values);
    assert Collections.binarySearch(values, 3) == 1;
    Collections.reverse(values);
    assert values.equals(List.of(5, 3, 1));
  }
}
