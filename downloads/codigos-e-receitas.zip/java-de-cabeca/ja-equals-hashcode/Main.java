import java.util.Objects;
import java.util.HashSet;
import java.util.Set;

public class Main {
  static final class Key {
    private final String id;
    Key(String id) { this.id = Objects.requireNonNull(id); }
    @Override public boolean equals(Object other) {
      return this == other || (other instanceof Key key && id.equals(key.id));
    }
    @Override public int hashCode() { return Objects.hash(id); }
  }
  public static void main(String[] args) {
    Set<Key> keys = new HashSet<>();
    keys.add(new Key("A"));
    keys.add(new Key("A"));
    assert keys.size() == 1;
    assert new Key("A").hashCode() == new Key("A").hashCode();
  }
}
