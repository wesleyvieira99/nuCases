public class Main {
    static final int LIMITE = 3;
    static boolean permitido(int n) { return n <= LIMITE; }
    public static void main(String[] args) {
        final StringBuilder texto = new StringBuilder("a");
        texto.append("b");
        assert texto.toString().equals("ab");
        assert Main.permitido(3);
        assert !Main.permitido(4);
    }
}
