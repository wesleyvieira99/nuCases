public class Main {
    public static void main(String[] args) {
        int[] valores = {-1, 0, 2, 8};
        int positivos = 0;
        for (int valor : valores) {
            if (valor > 0) positivos++;
        }
        assert positivos == 2;
    }
}
