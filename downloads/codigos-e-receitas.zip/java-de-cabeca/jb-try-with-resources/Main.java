public class Main {
    static class Recurso implements AutoCloseable {
        boolean fechado;
        @Override public void close() { fechado = true; }
    }
    public static void main(String[] args) {
        Recurso recurso = new Recurso();
        boolean capturou = false;
        try (recurso) {
            throw new IllegalStateException("falha");
        } catch (IllegalStateException erro) {
            capturou = true;
        }
        assert capturou && recurso.fechado;
    }
}
