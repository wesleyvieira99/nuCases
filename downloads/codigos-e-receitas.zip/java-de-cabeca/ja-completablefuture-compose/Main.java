import java.util.concurrent.CompletableFuture;

public class Main {
  static CompletableFuture<Integer> doubled(int value) {
    return CompletableFuture.completedFuture(value * 2);
  }
  public static void main(String[] args) {
    CompletableFuture<Integer> total = CompletableFuture.completedFuture(20)
        .thenApply(value -> value + 1)
        .thenCompose(value -> doubled(value));
    assert total.join() == 42;
  }
}
