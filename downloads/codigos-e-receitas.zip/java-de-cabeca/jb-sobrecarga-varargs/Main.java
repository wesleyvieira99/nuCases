public class Main {
    static int soma(int a, int b) { return a + b; }
    static long soma(long... valores) {
        long total = 0;
        for (long valor : valores) total += valor;
        return total;
    }
    public static void main(String[] args) {
        assert soma(2, 3) == 5;
        assert soma(2L, 3L, 4L) == 9L;
        assert soma() == 0L;
    }
}
