public class Main {
    public static void main(String[] args) {
        int quantidade = 3;
        long total = 3_000_000_000L;
        double media = 2.5;
        boolean ativo = true;
        char inicial = 'N';
        Integer caixa = quantidade;
        int valor = caixa;
        assert valor == 3 && total > Integer.MAX_VALUE;
        assert media == 2.5 && ativo && inicial == 'N';
    }
}
