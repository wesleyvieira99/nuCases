public class Main {
    public static void main(String[] args) {
        int[] valores = {2, 4, 6};
        int soma = 0;
        for (int i = 0; i < valores.length; i++) {
            soma += valores[i];
        }
        assert soma == 12;
        assert new int[0].length == 0;
    }
}
