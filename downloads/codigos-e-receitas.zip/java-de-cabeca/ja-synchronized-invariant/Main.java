public class Main {
  static final class Account {
    private int balance = 100;
    synchronized boolean withdraw(int amount) {
      if (amount <= 0) throw new IllegalArgumentException("amount");
      if (balance < amount) return false;
      balance -= amount;
      return true;
    }
    synchronized int balance() { return balance; }
  }
  public static void main(String[] args) throws InterruptedException {
    Account account = new Account();
    Thread first = new Thread(() -> account.withdraw(80));
    Thread second = new Thread(() -> account.withdraw(80));
    first.start();
    second.start();
    first.join();
    second.join();
    assert account.balance() == 20;
  }
}
