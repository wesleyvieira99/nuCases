public class Main {
    static int maior(int a, int b) {
        return a >= b ? a : b;
    }
    public static void main(String[] args) {
        int resultado = maior(7, 3);
        assert resultado == 7;
        assert maior(-2, -1) == -1;
    }
}
