import java.util.concurrent.CompletableFuture;

public class Main {
  public static void main(String[] args) {
    CompletableFuture<Integer> failed = CompletableFuture.failedFuture(
        new IllegalStateException("unavailable"));
    int fallback = failed.exceptionally(error -> -1).join();
    String outcome = failed.handle((value, error) ->
        error == null ? "ok:" + value : "failed").join();
    assert fallback == -1;
    assert outcome.equals("failed");
    assert failed.isCompletedExceptionally();
  }
}
