import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class Main {
  public static void main(String[] args) throws Exception {
    ExecutorService pool = Executors.newFixedThreadPool(2);
    try {
      Future<Integer> result = pool.submit(() -> 21 * 2);
      int value = result.get(2, TimeUnit.SECONDS);
      assert value == 42;
    } finally {
      pool.shutdown();
      if (!pool.awaitTermination(2, TimeUnit.SECONDS)) pool.shutdownNow();
    }
  }
}
