import java.math.BigDecimal;
import java.math.RoundingMode;

public class Main {
  public static void main(String[] args) {
    BigDecimal part = new BigDecimal("10")
        .divide(new BigDecimal("3"), 2, RoundingMode.HALF_EVEN);
    BigDecimal rounded = new BigDecimal("2.345")
        .setScale(2, RoundingMode.HALF_EVEN);
    long cents = new BigDecimal("12.34").movePointRight(2).longValueExact();
    assert part.equals(new BigDecimal("3.33"));
    assert rounded.equals(new BigDecimal("2.34"));
    assert cents == 1234L;
  }
}
