public class Main {
    public static void main(String[] args) {
        var nome = "Nu";
        var quantidade = 2;
        var valores = new int[]{3, 4};
        quantidade += 1;
        assert nome.length() == 2;
        assert quantidade == 3 && valores[1] == 4;
    }
}
