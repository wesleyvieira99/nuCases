public class Main {
    public static void main(String[] args) {
        boolean tratou = false;
        boolean finalizou = false;
        try {
            Integer.parseInt("x");
        } catch (NumberFormatException erro) {
            tratou = true;
        } finally {
            finalizou = true;
        }
        assert tratou && finalizou;
    }
}
