public class Main {
    public static void main(String[] args) {
        int numero = Integer.parseInt("42");
        Integer objeto = Integer.valueOf("42");
        String texto = Integer.toString(numero);
        assert numero == 42 && objeto.equals(42);
        assert texto.equals("42");
        boolean rejeitou = false;
        try { Integer.parseInt("quarenta"); }
        catch (NumberFormatException erro) { rejeitou = true; }
        assert rejeitou;
    }
}
