import java.util.function.Predicate;
import java.util.function.Function;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.ArrayList;
import java.util.List;

public class Main {
  public static void main(String[] args) {
    Predicate<String> valid = text -> !text.isBlank();
    Function<String, Integer> length = String::length;
    List<String> received = new ArrayList<>();
    Consumer<String> save = received::add;
    Supplier<String> create = () -> "ok";
    String value = create.get();
    assert valid.test(value);
    assert length.apply(value) == 2;
    save.accept(value);
    assert received.equals(List.of("ok"));
  }
}
