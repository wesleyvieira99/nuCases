public class Main {
    public static void main(String[] args) {
        Conta conta = new Conta();
        conta.creditar(50);
        assert conta.saldo() == 50;
    }
}
class Conta {
    private int saldo;
    public void creditar(int valor) {
        if (valor <= 0) throw new IllegalArgumentException("valor");
        saldo += valor;
    }
    public int saldo() { return saldo; }
}
