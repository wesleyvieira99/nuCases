import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

public class Main {
  public static void main(String[] args) {
    var calls = new AtomicInteger();
    String present = Optional.ofNullable(" ana ")
        .map(String::trim)
        .orElseGet(() -> { calls.incrementAndGet(); return "unknown"; });
    String absent = Optional.<String>ofNullable(null)
        .orElseGet(() -> { calls.incrementAndGet(); return "unknown"; });
    assert present.equals("ana");
    assert absent.equals("unknown");
    assert calls.get() == 1;
  }
}
