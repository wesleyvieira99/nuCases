import java.time.LocalDate;
public class Main {
    public static void main(String[] args) {
        LocalDate data = LocalDate.of(2026, 10, 27);
        assert data.getYear() == 2026;
    }
}
