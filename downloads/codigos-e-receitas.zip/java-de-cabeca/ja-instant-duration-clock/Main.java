import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneOffset;

public class Main {
  public static void main(String[] args) {
    Clock clock = Clock.fixed(
        Instant.parse("2026-01-01T10:00:00Z"), ZoneOffset.UTC);
    Instant now = Instant.now(clock);
    Instant expiresAt = now.plus(Duration.ofMinutes(5));
    assert Duration.between(now, expiresAt).toSeconds() == 300;
    assert now.isBefore(expiresAt);
    assert !expiresAt.isBefore(expiresAt);
  }
}
