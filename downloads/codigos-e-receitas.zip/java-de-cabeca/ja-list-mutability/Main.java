import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;

public class Main {
  public static void main(String[] args) {
    List<String> fixed = List.of("A", "B");
    List<String> mutable = new ArrayList<>(fixed);
    mutable.add("C");
    assert fixed.size() == 2 && mutable.size() == 3;
    String[] array = {"X", "Y"};
    List<String> view = Arrays.asList(array);
    view.set(0, "Z");
    assert array[0].equals("Z");
    boolean rejected = false;
    try { fixed.add("C"); }
    catch (UnsupportedOperationException expected) { rejected = true; }
    assert rejected;
  }
}
