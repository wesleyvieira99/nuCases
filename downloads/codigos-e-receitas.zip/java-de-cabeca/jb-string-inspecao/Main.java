public class Main {
    public static void main(String[] args) {
        String texto = "staff-java";
        assert texto.length() == 10;
        assert texto.charAt(0) == 's';
        assert texto.indexOf("java") == 6;
        assert texto.indexOf("kotlin") == -1;
        assert texto.substring(0, 5).equals("staff");
        assert texto.startsWith("staff") && texto.contains("-");
    }
}
