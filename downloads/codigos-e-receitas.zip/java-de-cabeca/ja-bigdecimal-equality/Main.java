import java.math.BigDecimal;

public class Main {
  public static void main(String[] args) {
    BigDecimal a = new BigDecimal("10.0");
    BigDecimal b = new BigDecimal("10.00");
    assert a.compareTo(b) == 0;
    assert !a.equals(b);
    BigDecimal sum = new BigDecimal("0.1").add(new BigDecimal("0.2"));
    assert sum.compareTo(new BigDecimal("0.3")) == 0;
    assert a.compareTo(BigDecimal.ZERO) > 0;
  }
}
