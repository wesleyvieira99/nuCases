import java.util.concurrent.ConcurrentHashMap;

public class Main {
  public static void main(String[] args) throws InterruptedException {
    var counts = new ConcurrentHashMap<String, Integer>();
    Runnable work = () -> {
      for (int i = 0; i < 1000; i++) counts.merge("paid", 1, Integer::sum);
    };
    Thread first = new Thread(work);
    Thread second = new Thread(work);
    first.start(); second.start();
    first.join(); second.join();
    assert counts.get("paid") == 2000;
    assert counts.get("missing") == null;
  }
}
