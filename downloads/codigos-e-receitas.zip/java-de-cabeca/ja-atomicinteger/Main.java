import java.util.concurrent.atomic.AtomicInteger;

public class Main {
  public static void main(String[] args) throws InterruptedException {
    AtomicInteger count = new AtomicInteger();
    Runnable work = () -> {
      for (int i = 0; i < 1000; i++) count.incrementAndGet();
    };
    Thread first = new Thread(work);
    Thread second = new Thread(work);
    first.start(); second.start();
    first.join(); second.join();
    assert count.get() == 2000;
    boolean changed = count.compareAndSet(2000, 0);
    assert changed && count.get() == 0;
  }
}
