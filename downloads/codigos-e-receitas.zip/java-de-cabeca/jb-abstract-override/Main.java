public class Main {
    static abstract class Regra {
        protected final int limite;
        Regra(int limite) { this.limite = limite; }
        abstract boolean aceita(int valor);
    }
    static class AteLimite extends Regra {
        AteLimite(int limite) { super(limite); }
        @Override boolean aceita(int valor) { return valor <= limite; }
    }
    public static void main(String[] args) {
        Regra regra = new AteLimite(10);
        assert regra.aceita(10) && !regra.aceita(11);
    }
}
