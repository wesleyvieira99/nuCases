import java.util.PriorityQueue;
import java.util.Comparator;

public class Main {
  record Job(String id, int priority) {}
  public static void main(String[] args) {
    var order = Comparator.comparingInt(Job::priority)
        .thenComparing(Job::id);
    var queue = new PriorityQueue<Job>(order);
    queue.offer(new Job("B", 1));
    queue.offer(new Job("A", 1));
    queue.offer(new Job("C", 2));
    Job first = queue.poll();
    assert first.id().equals("A");
    assert queue.peek().id().equals("B");
  }
}
