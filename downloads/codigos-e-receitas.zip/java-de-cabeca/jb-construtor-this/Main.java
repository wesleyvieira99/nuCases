public class Main {
    static class Conta {
        private final String id;
        Conta(String id) { this.id = id; }
        String id() { return id; }
    }
    public static void main(String[] args) {
        Conta conta = new Conta("A1");
        assert conta.id().equals("A1");
    }
}
