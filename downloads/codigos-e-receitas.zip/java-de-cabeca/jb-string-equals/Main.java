import java.util.Objects;
public class Main {
    public static void main(String[] args) {
        String a = new String("java");
        String b = new String("java");
        assert a != b;
        assert a.equals(b);
        assert Objects.equals(null, null);
        assert !Objects.equals(null, "java");
        assert "java".equals(a);
    }
}
