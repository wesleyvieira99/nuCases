import java.util.List;

public class Main {
  public static void main(String[] args) {
    List<Integer> input = List.of(-1, 0, 2, 3);
    List<Integer> doubled = input.stream()
        .filter(value -> value > 0)
        .map(value -> value * 2)
        .toList();
    assert doubled.equals(List.of(4, 6));
    assert input.equals(List.of(-1, 0, 2, 3));
    assert List.<Integer>of().stream().toList().isEmpty();
  }
}
