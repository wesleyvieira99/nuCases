import java.util.TreeMap;

public class Main {
  public static void main(String[] args) {
    var bands = new TreeMap<Integer, String>();
    bands.put(10, "basic");
    bands.put(20, "plus");
    bands.put(30, "premium");
    assert bands.floorEntry(15).getKey() == 10;
    assert bands.ceilingEntry(15).getKey() == 20;
    assert bands.floorEntry(5) == null;
    var range = bands.subMap(10, true, 30, false);
    assert range.size() == 2;
  }
}
