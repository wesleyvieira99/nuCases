import java.util.ArrayDeque;
import java.util.Queue;

public class Main {
  public static void main(String[] args) {
    Queue<String> queue = new ArrayDeque<>();
    queue.offer("A");
    queue.offer("B");
    assert queue.peek().equals("A");
    String first = queue.poll();
    String second = queue.poll();
    String empty = queue.poll();
    assert first.equals("A") && second.equals("B");
    assert empty == null;
  }
}
