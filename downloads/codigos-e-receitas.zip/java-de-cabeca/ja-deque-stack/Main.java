import java.util.ArrayDeque;
import java.util.Deque;

public class Main {
  public static void main(String[] args) {
    Deque<String> stack = new ArrayDeque<>();
    stack.push("A");
    stack.push("B");
    assert stack.peek().equals("B");
    String first = stack.pop();
    String second = stack.pop();
    assert first.equals("B") && second.equals("A");
    assert stack.peek() == null;
  }
}
