import java.util.HashMap;
import java.util.Map;

public class Main {
  public static void main(String[] args) {
    Map<String, Integer> counts = new HashMap<>();
    int previous = counts.getOrDefault("pix", 0);
    counts.put("pix", previous + 1);
    assert counts.get("pix") == 1;
    assert counts.getOrDefault("card", 0) == 0;
    assert !counts.containsKey("card");
    counts.put("unknown", null);
    assert counts.containsKey("unknown");
    assert counts.getOrDefault("unknown", 99) == null;
  }
}
