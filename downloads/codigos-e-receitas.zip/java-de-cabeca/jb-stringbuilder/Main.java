public class Main {
    public static void main(String[] args) {
        StringBuilder buffer = new StringBuilder();
        buffer.append("id=").append(42);
        buffer.insert(0, "[");
        buffer.append(']');
        assert buffer.toString().equals("[id=42]");
        assert buffer.length() == 7;
    }
}
