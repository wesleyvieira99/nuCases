public class Main {
    public static void main(String[] args) {
        int atual = 0, soma = 0;
        while (atual < 10) {
            atual++;
            if (atual > 5) break;
            if (atual % 2 == 0) continue;
            soma += atual;
        }
        assert soma == 9;
    }
}
