import java.io.IOException;
public class Main {
    static void carregar(boolean disponivel) throws IOException {
        if (!disponivel) throw new IOException("indisponível");
    }
    public static void main(String[] args) {
        boolean capturou = false;
        try { carregar(false); }
        catch (IOException erro) {
            capturou = erro.getMessage().equals("indisponível");
        }
        assert capturou;
    }
}
