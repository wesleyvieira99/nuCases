public class Main {
    static void alterar(StringBuilder texto) {
        texto.append("b");
        texto = new StringBuilder("outro");
        texto.append("!");
    }
    public static void main(String[] args) {
        StringBuilder original = new StringBuilder("a");
        alterar(original);
        assert original.toString().equals("ab");
    }
}
