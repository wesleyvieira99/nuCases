public class Main {
    static int tamanho(Object valor) {
        if (valor instanceof String texto && !texto.isEmpty()) {
            return texto.length();
        }
        return 0;
    }
    public static void main(String[] args) {
        assert tamanho("java") == 4;
        assert tamanho(42) == 0;
        assert tamanho(null) == 0;
        assert tamanho("") == 0;
    }
}
