public class Main {
    public static void main(String[] args) {
        int a = 5, b = 2;
        double correto = (double) a / b;
        double tarde = (double) (a / b);
        int truncado = (int) 2.9;
        assert correto == 2.5;
        assert tarde == 2.0 && truncado == 2;
    }
}
