import java.util.ArrayList;
import java.util.List;

public class Main {
  public static void main(String[] args) {
    List<Integer> values = new ArrayList<>();
    values.add(10);
    values.add(20);
    values.add(30);
    values.set(0, 15);
    boolean removed = values.remove(Integer.valueOf(20));
    assert removed;
    assert values.equals(List.of(15, 30));
    assert values.get(1) == 30;
    assert values.size() == 2;
  }
}
