import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;

public class Main {
  public static void main(String[] args) {
    ZoneId zone = ZoneId.of("America/Sao_Paulo");
    Instant event = Instant.parse("2026-01-02T01:00:00Z");
    LocalDate date = event.atZone(zone).toLocalDate();
    Instant start = date.atStartOfDay(zone).toInstant();
    assert date.equals(LocalDate.of(2026, 1, 1));
    assert start.equals(Instant.parse("2026-01-01T03:00:00Z"));
    assert date.plusDays(1).equals(LocalDate.of(2026, 1, 2));
  }
}
