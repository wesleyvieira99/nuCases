public class Main {
    static String rotulo(int codigo) {
        return switch (codigo) {
            case 200, 201 -> "ok";
            case 429 -> {
                String motivo = "limite";
                yield motivo;
            }
            default -> "outro";
        };
    }
    public static void main(String[] args) {
        assert rotulo(201).equals("ok");
        assert rotulo(429).equals("limite");
        assert rotulo(500).equals("outro");
    }
}
