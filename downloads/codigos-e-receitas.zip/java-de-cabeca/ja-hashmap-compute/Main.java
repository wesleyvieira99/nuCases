import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;

public class Main {
  public static void main(String[] args) {
    Map<String, List<String>> purchases = new HashMap<>();
    purchases.computeIfAbsent("account-1", key -> new ArrayList<>())
        .add("purchase-1");
    purchases.computeIfAbsent("account-1", key -> new ArrayList<>())
        .add("purchase-2");
    assert purchases.size() == 1;
    assert purchases.get("account-1")
        .equals(List.of("purchase-1", "purchase-2"));
  }
}
