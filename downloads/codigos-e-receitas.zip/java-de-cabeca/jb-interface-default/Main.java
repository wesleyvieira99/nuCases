public class Main {
    interface Validador {
        boolean valido(int valor);
        default String nome() { return "positivo"; }
    }
    static class Positivo implements Validador {
        @Override
        public boolean valido(int valor) { return valor > 0; }
    }
    public static void main(String[] args) {
        Validador regra = new Positivo();
        assert regra.valido(1) && !regra.valido(0);
        assert regra.nome().equals("positivo");
    }
}
