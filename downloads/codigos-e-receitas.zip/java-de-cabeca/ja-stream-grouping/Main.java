import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Main {
  public static void main(String[] args) {
    List<String> statuses = List.of("paid", "failed", "paid");
    Map<String, Long> counts = statuses.stream()
        .collect(Collectors.groupingBy(
            status -> status, Collectors.counting()));
    assert counts.get("paid") == 2L;
    assert counts.get("failed") == 1L;
    assert counts.getOrDefault("pending", 0L) == 0L;
  }
}
