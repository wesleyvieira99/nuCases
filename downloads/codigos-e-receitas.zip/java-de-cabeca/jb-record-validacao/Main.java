public class Main {
    record Valor(long centavos) {
        Valor {
            if (centavos < 0) throw new IllegalArgumentException("centavos");
        }
    }
    public static void main(String[] args) {
        Valor valor = new Valor(100);
        assert valor.centavos() == 100;
        assert valor.equals(new Valor(100));
        boolean rejeitou = false;
        try { new Valor(-1); }
        catch (IllegalArgumentException erro) { rejeitou = true; }
        assert rejeitou;
    }
}
