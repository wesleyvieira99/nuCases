import java.util.HashSet;
import java.util.Set;

public class Main {
  public static void main(String[] args) {
    Set<String> seen = new HashSet<>();
    boolean first = seen.add("event-7");
    boolean duplicate = !seen.add("event-7");
    assert first;
    assert duplicate;
    assert seen.contains("event-7");
    assert seen.size() == 1;
    boolean removed = seen.remove("event-7");
    assert removed && seen.isEmpty();
  }
}
