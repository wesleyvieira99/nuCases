from dataclasses import dataclass
from typing import Dict, Iterable, Tuple

@dataclass(frozen=True)
class Transfer:
    id: str
    source: str
    target: str
    cents: int

@dataclass
class Snapshot:
    balances: Dict[str, int]
    applied: Dict[str, Tuple[str, str, int]]

def replay(initial: Snapshot, events: Iterable[Transfer]) -> Snapshot:
    balances = dict(initial.balances)
    applied = dict(initial.applied)
    if any(type(v) is not int or v < 0 for v in balances.values()):
        raise ValueError("invalid initial balance")
    for event in events:
        if not event.id or type(event.cents) is not int or event.cents <= 0:
            raise ValueError("invalid transfer")
        if event.source == event.target:
            raise ValueError("same account")
        fingerprint = (event.source, event.target, event.cents)
        if event.id in applied:
            if applied[event.id] != fingerprint:
                raise ValueError("idempotency conflict")
            continue
        if event.source not in balances or event.target not in balances:
            raise ValueError("unknown account")
        if balances[event.source] < event.cents:
            raise ValueError("insufficient funds")
        balances[event.source] -= event.cents
        balances[event.target] += event.cents
        applied[event.id] = fingerprint
    return Snapshot(balances, applied)

import unittest

class LedgerTests(unittest.TestCase):
    def setUp(self):
        self.initial = Snapshot({"A": 1000, "B": 100}, {})

    def test_duplicate_and_conservation(self):
        event = Transfer("t1", "A", "B", 300)
        result = replay(self.initial, [event, event])
        self.assertEqual(result.balances, {"A": 700, "B": 400})
        self.assertEqual(sum(result.balances.values()), 1100)
        self.assertEqual(replay(result, [event]), result)
        self.assertEqual(self.initial.balances["A"], 1000)

    def test_conflict(self):
        with self.assertRaisesRegex(ValueError, "conflict"):
            replay(self.initial, [Transfer("x", "A", "B", 10),
                                  Transfer("x", "A", "B", 20)])

    def test_failure_preserves_input(self):
        with self.assertRaisesRegex(ValueError, "insufficient"):
            replay(self.initial, [Transfer("x", "A", "B", 2000)])
        self.assertEqual(self.initial, Snapshot({"A": 1000, "B": 100}, {}))

    def test_invalid_and_empty(self):
        self.assertEqual(replay(self.initial, []), self.initial)
        for cents in (0, -1, True):
            with self.assertRaises(ValueError):
                replay(self.initial, [Transfer("x", "A", "B", cents)])

if __name__ == "__main__":
    unittest.main()