BEGIN;
CREATE TEMP TABLE entries (
  id bigint PRIMARY KEY,
  account_id text NOT NULL,
  occurred_at timestamptz NOT NULL,
  cents bigint NOT NULL
);
INSERT INTO entries VALUES
 (1,'A','2026-01-01T10:00:00Z',1000),
 (2,'A','2026-01-01T10:00:00Z',-300),
 (3,'A','2026-01-01T11:00:00Z',50),
 (4,'B','2026-01-01T10:00:00Z',500);
CREATE INDEX entries_account_cursor ON entries(account_id, occurred_at, id);

CREATE TEMP VIEW statement AS
SELECT id, account_id, occurred_at, cents,
       sum(cents) OVER (
         PARTITION BY account_id ORDER BY occurred_at,id
         ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
       ) AS balance
FROM entries;

SELECT * FROM statement WHERE account_id='A' ORDER BY occurred_at,id;
SELECT id,cents FROM entries
WHERE account_id='A'
  AND (occurred_at,id) > ('2026-01-01T10:00:00Z'::timestamptz,1::bigint)
ORDER BY occurred_at,id LIMIT 2;

DO $$
DECLARE balances numeric[]; ids bigint[];
BEGIN
  SELECT array_agg(balance ORDER BY occurred_at,id) INTO balances
    FROM statement WHERE account_id='A';
  IF balances <> ARRAY[1000,700,750]::numeric[] THEN
    RAISE EXCEPTION 'window mismatch';
  END IF;
  SELECT array_agg(id ORDER BY occurred_at,id) INTO ids
    FROM entries WHERE account_id='A'
      AND (occurred_at,id) > ('2026-01-01T10:00:00Z'::timestamptz,1::bigint);
  IF ids <> ARRAY[2,3]::bigint[] THEN RAISE EXCEPTION 'cursor mismatch'; END IF;
END;
$$;
EXPLAIN (ANALYZE, BUFFERS)
SELECT * FROM entries WHERE account_id='A' ORDER BY occurred_at,id LIMIT 2;
ROLLBACK;