import java.util.concurrent.Callable
import java.util.concurrent.Executors

data class Request(val id: String, val from: String, val to: String, val cents: Long)
data class Receipt(val id: String, val fromBalance: Long, val toBalance: Long)

class InMemoryBank(initial: Map<String, Long>) {
    private val balances = initial.toMutableMap()
    private val applied = mutableMapOf<String, Pair<Request, Receipt>>()
    init { require(initial.values.all { it >= 0 }) }

    @Synchronized
    fun transfer(request: Request): Receipt {
        require(request.id.isNotBlank() && request.cents > 0 && request.from != request.to)
        applied[request.id]?.let { (original, receipt) ->
            require(original == request) { "idempotency_conflict" }
            return receipt
        }
        val source = requireNotNull(balances[request.from])
        val target = requireNotNull(balances[request.to])
        require(source >= request.cents) { "insufficient_funds" }
        // Calculate every fallible value before modifying either balance.
        val newTarget = Math.addExact(target, request.cents)
        val receipt = Receipt(request.id, source - request.cents, newTarget)
        balances[request.from] = receipt.fromBalance
        balances[request.to] = receipt.toBalance
        applied[request.id] = request to receipt
        return receipt
    }

    @Synchronized
    fun snapshot(): Map<String, Long> = balances.toMap()
}

fun main() {
    val bank = InMemoryBank(mapOf("A" to 1000L, "B" to 0L))
    val request = Request("t1", "A", "B", 100)
    val pool = Executors.newFixedThreadPool(8)
    try {
        val jobs = List(100) { Callable { bank.transfer(request) } }
        val receipts = pool.invokeAll(jobs).map { it.get() }
        check(receipts.toSet().size == 1)
        check(bank.snapshot() == mapOf("A" to 900L, "B" to 100L))
        check(runCatching { bank.transfer(request.copy(cents = 200)) }.isFailure)
        val overflow = InMemoryBank(mapOf("A" to 10L, "B" to Long.MAX_VALUE))
        check(runCatching { overflow.transfer(Request("x", "A", "B", 1)) }.isFailure)
        check(overflow.snapshot()["A"] == 10L)
        println("Kotlin concurrency: 5 checks passed")
    } finally {
        pool.shutdownNow()
    }
}