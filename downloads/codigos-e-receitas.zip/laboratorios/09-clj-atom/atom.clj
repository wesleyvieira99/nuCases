(ns atom-lab
  (:require [clojure.test :refer [deftest is run-tests]]))

(defn apply-deposit [state {:keys [id cents] :as event}]
  (when-not (and (string? id) (not (empty? id)) (integer? cents) (pos? cents))
    (throw (ex-info "invalid event" {:event event})))
  (if (contains? (:seen state) id)
    (if (= cents (get-in state [:seen id]))
      state
      (throw (ex-info "idempotency conflict" {:id id})))
    (-> state
        (update :balance + cents)
        (assoc-in [:seen id] cents))))

(defn deposit! [state event]
  (swap! state apply-deposit event))

(deftest deduplication-test
  (let [state (atom {:balance 0 :seen {}})
        event {:id "d1" :cents 100}]
    (dotimes [_ 100] (deposit! state event))
    (is (= 100 (:balance @state)))
    (is (= {"d1" 100} (:seen @state)))
    (is (thrown-with-msg? clojure.lang.ExceptionInfo #"conflict"
          (deposit! state {:id "d1" :cents 200})))
    (is (= 100 (:balance @state)))
    (deposit! state {:id "d2" :cents 50})
    (is (= 150 (:balance @state)))))

(let [result (run-tests 'atom-lab)]
  (when (pos? (+ (:fail result) (:error result)))
    (System/exit 1)))