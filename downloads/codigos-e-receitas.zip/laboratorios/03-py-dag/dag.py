from heapq import heappop, heappush, heapify
from typing import Dict, List

def deployment_order(dependencies: Dict[str, List[str]]) -> List[str]:
    nodes = set(dependencies)
    for values in dependencies.values():
        nodes.update(values)
    outgoing = {node: set() for node in nodes}
    indegree = {node: 0 for node in nodes}
    for service, prerequisites in dependencies.items():
        for prerequisite in set(prerequisites):
            outgoing[prerequisite].add(service)
            indegree[service] += 1
    ready = [node for node in nodes if indegree[node] == 0]
    heapify(ready)
    result = []
    while ready:
        node = heappop(ready)
        result.append(node)
        for following in outgoing[node]:
            indegree[following] -= 1
            if indegree[following] == 0:
                heappush(ready, following)
    if len(result) != len(nodes):
        raise ValueError("dependency cycle")
    return result

import unittest

class DagTests(unittest.TestCase):
    def test_order(self):
        deps = {"api": ["db", "cache", "db"], "worker": ["db"], "db": []}
        result = deployment_order(deps)
        self.assertEqual(result, ["cache", "db", "api", "worker"])
        position = {node: i for i, node in enumerate(result)}
        for node, before in deps.items():
            for prerequisite in before:
                self.assertLess(position[prerequisite], position[node])

    def test_cycles_and_empty(self):
        self.assertEqual(deployment_order({}), [])
        for graph in ({"a": ["a"]}, {"a": ["b"], "b": ["a"]}):
            with self.assertRaises(ValueError):
                deployment_order(graph)

if __name__ == "__main__":
    unittest.main()