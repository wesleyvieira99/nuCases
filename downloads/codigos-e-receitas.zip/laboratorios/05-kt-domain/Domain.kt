data class Account(val id: String, val cents: Long) {
    init { require(id.isNotBlank()); require(cents >= 0) }
}

sealed interface Withdrawal
data class Approved(val account: Account) : Withdrawal
data class Declined(val reason: String) : Withdrawal

fun withdraw(account: Account, amount: Long): Withdrawal = when {
    amount <= 0 -> Declined("invalid_amount")
    amount > account.cents -> Declined("insufficient_funds")
    else -> Approved(account.copy(cents = account.cents - amount))
}

fun describe(result: Withdrawal): String = when (result) {
    is Approved -> "approved:${result.account.cents}"
    is Declined -> "declined:${result.reason}"
}

fun main() {
    val account = Account("A", 1000)
    check(withdraw(account, 300) == Approved(Account("A", 700)))
    check(withdraw(account, 1000) == Approved(Account("A", 0)))
    check(withdraw(account, 0) == Declined("invalid_amount"))
    check(withdraw(account, 1001) == Declined("insufficient_funds"))
    check(account.cents == 1000L)
    check(describe(withdraw(account, 300)) == "approved:700")
    println("Kotlin domain: 6 checks passed")
}