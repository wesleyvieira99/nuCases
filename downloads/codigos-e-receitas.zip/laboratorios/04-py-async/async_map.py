import asyncio
from typing import Awaitable, Callable, List, Sequence, TypeVar, cast

T = TypeVar("T")
R = TypeVar("R")

async def bounded_map(items: Sequence[T], concurrency: int,
                      fn: Callable[[T], Awaitable[R]]) -> List[R]:
    if type(concurrency) is not int or concurrency < 1:
        raise ValueError("positive concurrency required")
    # Every slot is filled before a successful return; failure propagates.
    results = cast(List[R], [None] * len(items))
    next_index = 0

    async def worker():
        nonlocal next_index
        while next_index < len(items):
            # No await between reading and advancing the index.
            index = next_index
            next_index += 1
            results[index] = await fn(items[index])

    tasks = [asyncio.create_task(worker())
             for _ in range(min(concurrency, len(items)))]
    try:
        await asyncio.gather(*tasks)
    finally:
        for task in tasks:
            if not task.done():
                task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
    return results

import unittest

class AsyncTests(unittest.IsolatedAsyncioTestCase):
    async def test_limit_and_order(self):
        active = peak = 0
        async def double(x):
            nonlocal active, peak
            active += 1
            peak = max(peak, active)
            try:
                await asyncio.sleep(0.001 * (5 - x))
                return x * 2
            finally:
                active -= 1
        self.assertEqual(await bounded_map([1, 2, 3, 4], 2, double), [2, 4, 6, 8])
        self.assertLessEqual(peak, 2)
        self.assertEqual(active, 0)
        self.assertEqual(await bounded_map([], 2, double), [])

    async def test_failure_drains_workers(self):
        active = 0
        async def work(x):
            nonlocal active
            active += 1
            try:
                if x == 1:
                    await asyncio.sleep(0.001)
                    raise RuntimeError("boom")
                await asyncio.sleep(1)
                return x
            finally:
                active -= 1
        with self.assertRaises(RuntimeError):
            await bounded_map([0, 1, 2, 3], 2, work)
        self.assertEqual(active, 0)

if __name__ == "__main__":
    unittest.main()