BEGIN;
CREATE TEMP TABLE accounts (
  id text PRIMARY KEY,
  balance bigint NOT NULL CHECK (balance >= 0)
);
INSERT INTO accounts VALUES ('A', 1000), ('B', 100);

CREATE FUNCTION pg_temp.transfer(p_from text, p_to text, p_amount bigint)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE touched integer;
BEGIN
  IF p_from IS NULL OR p_to IS NULL OR p_from = p_to
     OR p_amount IS NULL OR p_amount <= 0 THEN
    RAISE EXCEPTION 'invalid transfer';
  END IF;
  PERFORM id FROM accounts WHERE id IN (p_from, p_to) ORDER BY id FOR UPDATE;
  GET DIAGNOSTICS touched = ROW_COUNT;
  IF touched <> 2 THEN RAISE EXCEPTION 'unknown account'; END IF;
  UPDATE accounts SET balance = balance - p_amount
    WHERE id = p_from AND balance >= p_amount;
  IF NOT FOUND THEN RAISE EXCEPTION 'insufficient funds'; END IF;
  UPDATE accounts SET balance = balance + p_amount WHERE id = p_to;
END;
$$;

SELECT pg_temp.transfer('A', 'B', 300);
DO $$
BEGIN
  IF (SELECT balance FROM accounts WHERE id='A') <> 700
     OR (SELECT balance FROM accounts WHERE id='B') <> 400 THEN
    RAISE EXCEPTION 'wrong balances';
  END IF;
  BEGIN
    PERFORM pg_temp.transfer('A', 'B', 5000);
    RAISE EXCEPTION 'expected rejection';
  EXCEPTION WHEN raise_exception THEN
    IF SQLERRM <> 'insufficient funds' THEN RAISE; END IF;
  END;
  IF (SELECT sum(balance) FROM accounts) <> 1100 THEN
    RAISE EXCEPTION 'conservation failed';
  END IF;
END;
$$;
SELECT * FROM accounts ORDER BY id;
ROLLBACK;