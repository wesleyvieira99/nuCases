BEGIN;
CREATE TEMP TABLE balances(account_id text PRIMARY KEY, cents bigint NOT NULL CHECK(cents>=0));
CREATE TEMP TABLE inbox(event_id text PRIMARY KEY, account_id text NOT NULL, cents bigint NOT NULL);
CREATE TEMP TABLE outbox(event_id text PRIMARY KEY, payload jsonb NOT NULL, published_at timestamptz);
INSERT INTO balances VALUES ('A',0);

CREATE FUNCTION pg_temp.deposit(p_id text, p_account text, p_cents bigint)
RETURNS boolean LANGUAGE plpgsql AS $$
DECLARE inserted text; previous inbox%ROWTYPE;
BEGIN
  IF p_id IS NULL OR p_id = '' OR p_account IS NULL
     OR p_cents IS NULL OR p_cents <= 0 THEN
    RAISE EXCEPTION 'invalid event';
  END IF;
  INSERT INTO inbox VALUES(p_id,p_account,p_cents)
    ON CONFLICT (event_id) DO NOTHING RETURNING event_id INTO inserted;
  IF inserted IS NULL THEN
    SELECT * INTO STRICT previous FROM inbox WHERE event_id=p_id;
    IF previous.account_id <> p_account OR previous.cents <> p_cents THEN
      RAISE EXCEPTION 'idempotency conflict';
    END IF;
    RETURN false;
  END IF;
  UPDATE balances SET cents=cents+p_cents WHERE account_id=p_account;
  IF NOT FOUND THEN RAISE EXCEPTION 'unknown account'; END IF;
  INSERT INTO outbox(event_id,payload)
    VALUES(p_id,jsonb_build_object('type','deposit_applied','accountId',p_account,'cents',p_cents));
  RETURN true;
END;
$$;

DO $$
BEGIN
  IF NOT pg_temp.deposit('e1','A',100) THEN RAISE EXCEPTION 'first apply failed'; END IF;
  IF pg_temp.deposit('e1','A',100) THEN RAISE EXCEPTION 'duplicate applied'; END IF;
  BEGIN
    PERFORM pg_temp.deposit('e1','A',200);
    RAISE EXCEPTION 'expected conflict';
  EXCEPTION WHEN raise_exception THEN
    IF SQLERRM <> 'idempotency conflict' THEN RAISE; END IF;
  END;
  IF (SELECT cents FROM balances WHERE account_id='A') <> 100
     OR (SELECT count(*) FROM outbox) <> 1 THEN
    RAISE EXCEPTION 'invariant failed';
  END IF;
END;
$$;
SELECT * FROM outbox;
ROLLBACK;