from collections import defaultdict, deque
from typing import Deque, Dict, Optional

class SlidingWindow:
    def __init__(self, limit: int, window_ms: int):
        if type(limit) is not int or type(window_ms) is not int or limit <= 0 or window_ms <= 0:
            raise ValueError("positive integer limit and window required")
        self.limit = limit
        self.window_ms = window_ms
        self.events: Dict[str, Deque[int]] = defaultdict(deque)
        self.last_now: Optional[int] = None

    def allow(self, key: str, now_ms: int) -> bool:
        if type(now_ms) is not int:
            raise ValueError("integer timestamp required")
        if self.last_now is not None and now_ms < self.last_now:
            raise ValueError("time moved backwards")
        self.last_now = now_ms
        queue = self.events[key]
        while queue and queue[0] <= now_ms - self.window_ms:
            queue.popleft()
        if len(queue) >= self.limit:
            return False
        queue.append(now_ms)
        return True

import unittest

class WindowTests(unittest.TestCase):
    def test_boundary(self):
        r = SlidingWindow(2, 1000)
        self.assertTrue(r.allow("a", 0))
        self.assertTrue(r.allow("a", 1))
        self.assertFalse(r.allow("a", 999))
        self.assertTrue(r.allow("a", 1000))
        self.assertFalse(r.allow("a", 1000))
        self.assertTrue(r.allow("a", 1001))

    def test_keys_and_clock(self):
        r = SlidingWindow(1, 10)
        self.assertTrue(r.allow("a", 20))
        self.assertTrue(r.allow("b", 20))
        self.assertFalse(r.allow("a", 20))
        with self.assertRaises(ValueError):
            r.allow("a", 19)

if __name__ == "__main__":
    unittest.main()