(ns rules-lab
  (:require [clojure.test :refer [deftest is run-tests]]))

(defn authorize [account cents]
  (cond
    (not (and (integer? cents) (pos? cents)))
    {:status :declined :reason :invalid-amount}

    (not (:active? account))
    {:status :declined :reason :inactive-account}

    (> cents (:limit-cents account))
    {:status :declined :reason :operation-limit}

    (> cents (:balance-cents account))
    {:status :declined :reason :insufficient-funds}

    :else
    {:status :approved
     :account (update account :balance-cents - cents)}))

(deftest authorization-test
  (let [account {:active? true :balance-cents 1000 :limit-cents 500}]
    (is (= 700 (get-in (authorize account 300) [:account :balance-cents])))
    (is (= :operation-limit (:reason (authorize account 600))))
    (is (= :invalid-amount (:reason (authorize account -1))))
    (is (= :inactive-account (:reason (authorize (assoc account :active? false) 10))))
    (is (= :insufficient-funds
           (:reason (authorize (assoc account :balance-cents 10) 20)))))
  (is (= :invalid-amount (:reason (authorize {} nil)))))

(let [result (run-tests 'rules-lab)]
  (when (pos? (+ (:fail result) (:error result)))
    (System/exit 1)))