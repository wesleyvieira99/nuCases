import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

public class MoneyLab {
    public static List<BigDecimal> allocate(BigDecimal total, int people) {
        if (total == null || total.signum() < 0 || people <= 0) {
            throw new IllegalArgumentException("nonnegative amount and positive people required");
        }
        // Reject fractional cents instead of rounding silently.
        BigInteger cents = total.movePointRight(2).toBigIntegerExact();
        BigInteger[] quotient = cents.divideAndRemainder(BigInteger.valueOf(people));
        int remainder = quotient[1].intValueExact();
        List<BigDecimal> result = new ArrayList<>(people);
        for (int i = 0; i < people; i++) {
            BigInteger share = quotient[0].add(i < remainder ? BigInteger.ONE : BigInteger.ZERO);
            result.add(new BigDecimal(share, 2));
        }
        return List.copyOf(result);
    }
}

class MoneyLabTest {
    static void verify(boolean value) {
        if (!value) throw new AssertionError("check failed");
    }
    public static void main(String[] args) {
        List<BigDecimal> result = MoneyLab.allocate(new BigDecimal("10.00"), 3);
        verify(result.toString().equals("[3.34, 3.33, 3.33]"));
        verify(result.stream().reduce(BigDecimal.ZERO, BigDecimal::add)
            .compareTo(new BigDecimal("10.00")) == 0);
        verify(MoneyLab.allocate(new BigDecimal("0.01"), 3).toString()
            .equals("[0.01, 0.00, 0.00]"));
        boolean rejected = false;
        try { MoneyLab.allocate(new BigDecimal("0.001"), 2); }
        catch (ArithmeticException expected) { rejected = true; }
        verify(rejected);
        System.out.println("Java money: 4 checks passed");
    }
}