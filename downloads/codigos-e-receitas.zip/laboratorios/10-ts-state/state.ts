type Payment =
  | { status: "pending"; cents: bigint }
  | { status: "authorized"; cents: bigint; authorizationId: string }
  | { status: "captured"; cents: bigint; authorizationId: string; captureId: string };

type Command =
  | { type: "authorize"; authorizationId: string }
  | { type: "capture"; captureId: string };

function transition(state: Payment, command: Command): Payment {
  if (state.cents <= 0n) throw new Error("invalid_amount");
  switch (command.type) {
    case "authorize":
      if (!command.authorizationId.trim()) throw new Error("invalid_id");
      if (state.status !== "pending") throw new Error("invalid_transition");
      return { ...state, status: "authorized", authorizationId: command.authorizationId };
    case "capture":
      if (!command.captureId.trim()) throw new Error("invalid_id");
      if (state.status === "captured" && state.captureId === command.captureId) return state;
      if (state.status !== "authorized") throw new Error("invalid_transition");
      return { ...state, status: "captured", captureId: command.captureId };
    default: {
      const unreachable: never = command;
      throw new Error(`unknown command: ${String(unreachable)}`);
    }
  }
}

function check(value: boolean): void { if (!value) throw new Error("check failed"); }
function throws(fn: () => unknown): boolean { try { fn(); return false; } catch { return true; } }
const pending: Payment = { status: "pending", cents: 1200n };
const authorized = transition(pending, { type: "authorize", authorizationId: "a1" });
const captured = transition(authorized, { type: "capture", captureId: "c1" });
check(captured.status === "captured");
check(transition(captured, { type: "capture", captureId: "c1" }) === captured);
check(throws(() => transition(pending, { type: "capture", captureId: "c1" })));
check(throws(() => transition(captured, { type: "capture", captureId: "c2" })));
check(pending.status === "pending");
console.log("TypeScript states: 5 checks passed");