async function mapLimited<T, R>(
  items: readonly T[], limit: number, fn: (item: T, index: number) => Promise<R>
): Promise<R[]> {
  if (!Number.isInteger(limit) || limit < 1) throw new Error("invalid_limit");
  const results = new Array<R>(items.length);
  let next = 0;
  let failed = false;
  let firstError: unknown;
  async function worker(): Promise<void> {
    while (!failed && next < items.length) {
      const index = next++;
      try {
        results[index] = await fn(items[index], index);
      } catch (error) {
        if (!failed) { failed = true; firstError = error; }
      }
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, () => worker()));
  if (failed) throw firstError;
  return results;
}

function check(value: boolean): void { if (!value) throw new Error("check failed"); }
const delay = (ms: number) => new Promise<void>(resolve => setTimeout(resolve, ms));
async function tests(): Promise<void> {
  let active = 0, peak = 0;
  const result = await mapLimited([1, 2, 3, 4], 2, async value => {
    active++; peak = Math.max(peak, active);
    try { await delay(5 - value); return value * 2; } finally { active--; }
  });
  check(JSON.stringify(result) === "[2,4,6,8]");
  check(peak <= 2 && active === 0);
  let rejected = false;
  try {
    await mapLimited([0, 1, 2, 3], 2, async value => {
      active++;
      try { await delay(value === 1 ? 1 : 10); if (value === 1) throw new Error("boom"); return value; }
      finally { active--; }
    });
  } catch { rejected = true; }
  check(rejected && active === 0);
  check((await mapLimited([], 2, async x => x)).length === 0);
  console.log("TypeScript workers: 4 checks passed");
}
void tests().catch(error => { console.error(error); throw error; });